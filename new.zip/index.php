<?php

echo "Casino Scouts!";